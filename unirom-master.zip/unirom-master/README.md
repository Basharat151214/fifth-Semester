# UNIROM - A UMS built with JavaFX and SQLite
Everything is in /SRC folder the code is simple and understandable you can ask if you don't understand any part.
Clone this repo and make pages you selected will integerate after completion.
![alt text](http://fayzan.me/wp-content/uploads/2019/11/Annotation-2019-11-12-011030.png)
![alt text](http://fayzan.me/wp-content/uploads/2019/11/Annotation-2019-11-12-011059.png)
![alt text](http://fayzan.me/wp-content/uploads/2019/11/Annotation-2019-11-12-011059s.png)
